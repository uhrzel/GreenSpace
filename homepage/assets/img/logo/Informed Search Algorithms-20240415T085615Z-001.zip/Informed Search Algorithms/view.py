import tkinter as tk
from tkinter import ttk
from graphics.graph import Graph
from graphics.node_edge import Node
from search_algos import Searcher
from typing import List
import time

class View:
    def __init__(self, parent):
        self.container = parent
        self.searcher: Searcher = None
        self.nodes = []

    def set_searcher(self, searcher):
        self.searcher = searcher

    def setup(self):
        self.create_widgets()
        self.setup_layout()

    def create_widgets(self):
        self.main_pane = ttk.PanedWindow(self.container, orient=tk.HORIZONTAL)
        self.left_frame = ttk.Frame(self.main_pane, padding=10)
        self.canvas_frame = ttk.Frame(self.main_pane, padding=5)

        # left frame widgets
        self.algo_frame = ttk.LabelFrame(self.left_frame, text="Algorithm Selection", padding=5)
        self.search_choice = tk.StringVar()
        self.search_choice.set("DFS")
        self.sc_rb1 = ttk.Radiobutton(self.algo_frame, text="Depth-First Search", variable=self.search_choice, value="DFS")
        self.sc_rb2 = ttk.Radiobutton(self.algo_frame, text="Breadth-First Search", variable=self.search_choice, value="BFS")
        self.sc_rb3 = ttk.Radiobutton(self.algo_frame, text="Iterative Deepening Depth-First Search", variable=self.search_choice, value="IDDFS")
        self.sc_rb4 = ttk.Radiobutton(self.algo_frame, text="Minimax Search", variable=self.search_choice, value="MS")
        self.sc_rb5 = ttk.Radiobutton(self.algo_frame, text="Alpha-Beta Pruning", variable=self.search_choice, value="ABP")
        self.sc_rb6 = ttk.Radiobutton(self.algo_frame, text="A* Search", variable=self.search_choice, value="A*")

        self.spacing_frame1 = ttk.Frame(self.left_frame, padding=5, height=10)

        self.setup_frame = ttk.LabelFrame(self.left_frame, text="Setup")
        self.src_frame = ttk.Frame(self.setup_frame, padding=5)
        self.src_cb_label = ttk.Label(self.src_frame, text="Source Node:")
        self.src_node_cb = ttk.Combobox(self.src_frame, state="readonly", 
                                        postcommand=lambda: self.src_node_cb.configure(values=[node.tag[1:] for node in self.nodes]))
        self.dst_frame = ttk.Frame(self.setup_frame, padding=5)
        self.dst_cb_label = ttk.Label(self.dst_frame, text="Find Node:")
        self.dst_node_cb = ttk.Combobox(self.dst_frame, state="readonly", values=[None], 
                                        postcommand=lambda: self.dst_node_cb.configure(values=[None] + [node.tag[1:] for node in self.nodes]))
        self.dst_node_cb.current(0)

        self.output_frame = ttk.Frame(self.left_frame)
        self.output_label = ttk.Label(self.output_frame, text="Output:")
        self.output_text = tk.Text(self.output_frame, wrap=tk.WORD, state="disabled", width=30)

        def color_path(path: List[Node], color="red"):
            start: Node = path[0]
            weights = []
            for node in path[1:]:
                for edge in start.get_edges_to(node):
                    if edge.directed and edge.node2 == start:
                        continue
                    edge.color = color
                    weights.append(edge.weight)
                    edge.draw()
                start = node
            return weights

        def search():
            src = self.src_node_cb.get()
            dst = self.dst_node_cb.get()
            for node in self.nodes:
                if node.tag[1:] == src:
                    src = node
                    break
            for node in self.nodes:
                if node.tag[1:] == dst:
                    dst = node
                    break
            if not isinstance(dst, Node):
                dst = None
            if src:
                choice = self.search_choice.get()
                if choice in ["DFS", "BFS", "IDDFS", "A*"]:
                    if choice == "DFS":
                        self.graph.reset()
                        output, found = self.searcher.dfs(src, dst)
                        if output:
                            output = "Path: " + " -> ".join([node.tag[1:] for node in output])
                    elif choice == "BFS":
                        self.graph.reset()
                        output, found = self.searcher.bfs(src, dst)
                        if output:
                            output = "Path: " + " -> ".join([node.tag[1:] for node in output])
                    elif choice == "IDDFS":
                        self.graph.reset()
                        output, found = self.searcher.iddfs(src, dst)
                        if output:
                            output = "\n".join([f"Level {depth}: " + " -> ".join([node.tag[1:] for node in path]) for depth, path in output.items()])
                    elif choice == "A*":
                        output = self.searcher.a_star(src, dst)
                        if output is not None:
                            costs = color_path(output)
                            output = "Path: " + " -> ".join([node.tag[1:] for node in output])
                            output += "\nCost: " + " + ".join([str(cost) for cost in costs]) + f" = {sum(costs)}"
                            found = True if output is not None else False
                    if dst and found:
                        output += f"\nNode {dst.tag[1:]} Found!"
                    self.output_text.config(state="normal")
                    self.output_text.delete(1.0, tk.END)
                    self.output_text.insert(tk.END, output)
                    self.output_text.config(state="disabled")
                else:
                    self.graph.reset()
                    self.output_text.config(state="normal")
                    self.output_text.delete(1.0, tk.END)
                    ab = True if choice == "ABP" else False
                    start_time = time.time()
                    _, path = self.searcher.minimax(src, True, ab=ab)
                    time_lapsed = time.time() - start_time
                    output = "Optimized Path: " + " -> ".join([node.tag[1:] for node in path])
                    output += f"\nTime Lapsed: {time_lapsed:.4f} seconds"
                    self.output_text.insert(tk.END, output)
                    self.output_text.config(state="disabled")

                    color_path(path)

        self.search_btn = ttk.Button(self.setup_frame, text="Search", command=search)

        # canvas frame widget
        self.graph = Graph(self.canvas_frame, self.nodes, bg="white", width=800, height=600, bd=1, relief=tk.SUNKEN)

    def setup_layout(self):
        self.main_pane.add(self.left_frame)
        self.main_pane.add(self.canvas_frame)
        self.main_pane.pack(anchor=tk.NW, fill=tk.BOTH, expand=True)

        self.algo_frame.pack(anchor=tk.NW, fill=tk.X, expand=True)
        self.sc_rb1.pack(fill=tk.X)
        self.sc_rb2.pack(fill=tk.X)
        self.sc_rb3.pack(fill=tk.X)
        self.sc_rb4.pack(fill=tk.X)
        self.sc_rb5.pack(fill=tk.X)
        self.sc_rb6.pack(fill=tk.X)

        self.create_spacing(self.left_frame, pad_top=5, pad_bottom=5, show_sep=False)
        self.setup_frame.pack(anchor=tk.NW, fill=tk.X, expand=True)
        self.src_frame.pack(fill=tk.X, expand=True)
        self.src_cb_label.pack(side=tk.LEFT)
        self.src_node_cb.pack(side=tk.RIGHT)
        self.dst_frame.pack(fill=tk.X, expand=True)
        self.dst_cb_label.pack(side=tk.LEFT)
        self.dst_node_cb.pack(side=tk.RIGHT)
        self.search_btn.pack(fill=tk.X)

        self.create_spacing(self.left_frame, pad_top=5, pad_bottom=5, show_sep=False)
        self.output_frame.pack(anchor=tk.NW, fill=tk.X, expand=True)
        self.output_label.pack(anchor=tk.W, fill=tk.X)
        self.output_text.pack(fill=tk.BOTH, expand=True)

        self.create_spacing(self.left_frame, pad_top=5, pad_bottom=5, show_sep=False)

        self.graph.pack(fill=tk.BOTH, expand=True)

    @staticmethod
    def create_spacing(parent, pad_left=0, pad_right=0, pad_top=0, pad_bottom=0, show_sep=True, sep_orient=tk.HORIZONTAL):
        sep_frame = tk.Frame(parent)
        sep_frame.pack(padx=(pad_left, pad_right), pady=(pad_top, pad_bottom), fill=tk.X)
        separator = ttk.Separator(sep_frame, orient=sep_orient)
        separator.pack(fill=tk.X) if show_sep else separator.pack_forget()
