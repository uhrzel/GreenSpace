import tkinter as tk
from tkinter import ttk, simpledialog
from graphics.node_edge import Node, Edge
from typing import List, Dict

class Graph(tk.Canvas):
    def __init__(self, parent, nodes, *args, **kwargs):
        super().__init__(parent, *args, **kwargs)
        self.nodes: List[Node] = nodes

        self.add_node_menu = tk.Menu(self, tearoff=0)
        self.add_node_menu.add_command(label="Add Node", command=self.add_node)
        self.selected_node = None
        self.open_node_menu = False
        self.bind("<Button-3>", self.show_popup)
        self.selected_end_node = None

        self.node_menu = tk.Menu(self, tearoff=0)
        self.node_menu.add_command(label="Rename Node", command=self.rename_node)
        self.node_menu.add_command(label="Add Edge", command=self.add_edge)
        self.node_menu.add_command(label="Set Value", command=self.set_node_value)
        self.node_menu.add_command(label="Set Edge Weight", command=self.set_edge_weight)
        self.node_menu.add_command(label="Delete Edge", command=self.delete_edge)
        self.node_menu.add_command(label="Delete Node", command=self.delete_node)

    def reset(self):
        for node in self.nodes:
            node.dark_mode = False
            node.additional_items = []
            edge_sets = node.edges.values()
            for edge_set in edge_sets:
                for edge in edge_set:
                    edge.dashed = False
                    edge.color = "black"
            node.redraw()

    def node_menu_mode(self, node: Node):
        self.selected_node = node
        self.open_node_menu = True

    def show_popup(self, event: tk.Event):
        try:
            self.event = event
            if self.selected_node and self.open_node_menu:
                self.node_menu.tk_popup(event.x_root, event.y_root, 0)
            else:
                self.add_node_menu.tk_popup(event.x_root, event.y_root, 0)
        finally:
            if self.open_node_menu:
                self.node_menu.grab_release()
                self.open_node_menu = False
            else:
                self.add_node_menu.grab_release()

    def add_node(self):
        self.popup = self.generate_small_popup(self, "Add Node", self.event.x_root, self.event.y_root)

        ttk.Label(self.popup, text="Node Name:").pack(pady=5)
        node_entry = ttk.Entry(self.popup)
        node_entry.pack(pady=5)
        node_entry.focus_set()
        node_entry.bind("<Return>", lambda event: self.create_node(node_entry.get()))
        add_node_btn = ttk.Button(self.popup, text="Add Node", 
                    command=lambda: self.create_node(node_entry.get()))
        add_node_btn.pack(pady=5)

    def create_node(self, node_name):
        if node_name in [node.tag[1:] for node in self.nodes]:
            self.popup.destroy()
            return  # TODO: no error message for now

        node = Node(self, node_name, self.event.x, self.event.y)
        self.tag_bind(node.tag, "<Button-3>", lambda event, x=node: self.node_menu_mode(x))
        self.nodes.append(node)
        self.popup.destroy()

    def rename_node(self):
        title = f"Rename Node: {self.selected_node.tag[1:]}"
        self.popup = self.generate_small_popup(self, title, self.event.x_root, self.event.y_root)

        ttk.Label(self.popup, text="Node Name:").pack(pady=5)
        entry = ttk.Entry(self.popup)
        entry.pack(pady=5)
        entry.focus_set()

        def rename():
            new_name = entry.get()
            if new_name in [node.tag[1:] for node in self.nodes]:
                self.popup.destroy()
                return  # TODO: no error message for now
            node = self.selected_node.rename(entry.get())
            self.tag_bind(node.tag, "<Button-3>", lambda event, x=node: self.node_menu_mode(x))
            self.popup.destroy()

        entry.bind("<Return>", lambda event: rename())
        rename_btn = ttk.Button(self.popup, text="Rename Node", 
                    command=lambda: rename())
        rename_btn.pack(pady=5)

    def delete_node(self):
        self.selected_node.delete()
        self.nodes.remove(self.selected_node)

    def add_edge(self):
        self.config(cursor="circle")
        self.bind("<Button-1>", self.select_end_node)

    def select_end_node(self, event: tk.Event):
        x, y = event.x, event.y
        for node in self.nodes:
            if node.contains(x, y):
                self.selected_end_node = node
                self.create_edge()
                break
        self.config(cursor="arrow")
        self.unbind("<Button-1>")

    def create_edge(self):
        node1 = self.selected_node
        node2 = self.selected_end_node

        self.popup = self.generate_small_popup(self, "Add Edge", self.event.x_root, self.event.y_root)
        directed = tk.BooleanVar()
        directed_cb = ttk.Checkbutton(self.popup, text="Directed", variable=directed)
        directed_cb.pack(pady=5)

        add_edge_btn = ttk.Button(self.popup, text="Add Edge", 
                command=lambda: [self.popup.destroy(), node1.add_edge(node2, directed=directed.get())])
        add_edge_btn.pack(pady=5)

    def delete_edge(self):
        node1 = self.selected_node
        self.popup = self.generate_small_popup(self, "Delete Edge", self.event.x_root, self.event.y_root, geometry="200x275")
        if not node1.edges:
            ttk.Label(self.popup, text="No edges to delete.").pack(pady=5)
            return

        main = ttk.Frame(self.popup, padding=5)
        node2_select_frame = ttk.Frame(main)
        ttk.Label(node2_select_frame, text="Node to:").pack(side=tk.LEFT, pady=5)

        edge_map: Dict[str, Edge] = {}
        def update_edge_list(*args):
            node2 = node2_cb.get()
            edge_listbox.delete(0, tk.END)
            edge_map.clear()
            for edge in node1.get_edges_to("_" + node2):
                edge_str = str(edge)
                edge_map[edge_str] = edge
                edge_listbox.insert(tk.END, edge_str)
    
        node2_cb = ttk.Combobox(node2_select_frame, state="readonly",
                                values=[node.tag[1:] for node in node1.edges.keys()])
        node2_cb.current(0)
        node2_cb.bind("<<ComboboxSelected>>", update_edge_list)
        node2_cb.focus_set()
        node2_cb.pack(side=tk.LEFT, pady=5)
        node2_select_frame.pack()

        edge_list_frame = ttk.Frame(main, width=200)
        ttk.Label(edge_list_frame, text="Edges:").pack(anchor=tk.NW)
        list_frame = tk.Frame(edge_list_frame, relief=tk.SUNKEN, bd=1, background="white")
        edge_listbox = tk.Listbox(list_frame, selectmode=tk.SINGLE, borderwidth=0, highlightthickness=0,
                                background=list_frame.cget("background"))
        edge_list_sb = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=edge_listbox.yview)
        edge_listbox.config(yscrollcommand=edge_list_sb.set)
        edge_list_sb.pack(side=tk.RIGHT, fill=tk.Y)
        edge_listbox.pack(side=tk.TOP, padx=5, pady=5, fill=tk.BOTH, expand=True)
        list_frame.pack(fill=None, expand=False)
        edge_list_frame.pack(anchor=tk.NW, fill=tk.X, expand=True)
        update_edge_list()

        def del_edge():
            selected = edge_listbox.get(tk.ANCHOR)
            edge = edge_map[selected]
            edge.delete()

        btn = ttk.Button(main, text="Delete Edge", command=lambda: [del_edge(), self.popup.destroy()])
        btn.pack(anchor=tk.SE, pady=5)

        main.pack()

    def set_node_value(self):
        value = simpledialog.askfloat("Set Value", "Input Value:")
        self.selected_node.set_value(value)

    def set_edge_weight(self):
        node1 = self.selected_node
        self.popup = self.generate_small_popup(self, "Set Edge Weight", self.event.x_root, self.event.y_root, geometry="200x300")
        if not node1.edges:
            ttk.Label(self.popup, text="No edges to set weight.").pack(pady=5)
            return

        main = ttk.Frame(self.popup, padding=5)
        node2_select_frame = ttk.Frame(main)
        ttk.Label(node2_select_frame, text="Node to:").pack(side=tk.LEFT, pady=5)

        edge_map: Dict[str, Edge] = {}
        def update_edge_list(*args):
            node2 = node2_cb.get()
            edge_listbox.delete(0, tk.END)
            edge_map.clear()
            for edge in node1.get_edges_to("_" + node2):
                edge_str = str(edge)
                edge_map[edge_str] = edge
                edge_listbox.insert(tk.END, edge_str)
    
        node2_cb = ttk.Combobox(node2_select_frame, state="readonly",
                                values=[node.tag[1:] for node in node1.edges.keys()])
        node2_cb.current(0)
        node2_cb.bind("<<ComboboxSelected>>", update_edge_list)
        node2_cb.focus_set()
        node2_cb.pack(side=tk.LEFT, pady=5)
        node2_select_frame.pack()

        edge_list_frame = ttk.Frame(main, width=200)
        ttk.Label(edge_list_frame, text="Edges:").pack(anchor=tk.NW)
        list_frame = tk.Frame(edge_list_frame, relief=tk.SUNKEN, bd=1, background="white")
        edge_listbox = tk.Listbox(list_frame, selectmode=tk.SINGLE, borderwidth=0, highlightthickness=0,
                                background=list_frame.cget("background"))
        edge_list_sb = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=edge_listbox.yview)
        edge_listbox.config(yscrollcommand=edge_list_sb.set)
        edge_list_sb.pack(side=tk.RIGHT, fill=tk.Y)
        edge_listbox.pack(side=tk.TOP, padx=5, pady=5, fill=tk.BOTH, expand=True)
        list_frame.pack(fill=None, expand=False)
        edge_list_frame.pack(anchor=tk.NW, fill=tk.X, expand=True)
        update_edge_list()

        weight_frame = ttk.Frame(main)
        ttk.Label(weight_frame, text="Weight:").pack(side=tk.LEFT, pady=5)
        weight_entry = ttk.Entry(weight_frame)
        weight_entry.pack(side=tk.LEFT, pady=5)
        weight_frame.pack()

        def set_weight():
            selected = edge_listbox.get(tk.ANCHOR)
            edge = edge_map[selected]
            edge.set_weight(weight_entry.get())

        btn = ttk.Button(main, text="Set Weight", command=lambda: [set_weight(), self.popup.destroy()])
        btn.pack(anchor=tk.SE, pady=5)

        main.pack()

    @staticmethod
    def generate_small_popup(parent, title, x, y, geometry="200x100"):
        popup = tk.Toplevel(parent)
        popup.title(title)
        popup.geometry(f"{geometry}+{x}+{y}")
        popup.grab_set()
        popup.transient(parent)
        return popup