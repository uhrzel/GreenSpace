from graphics.node_edge import Node
from collections import deque
from typing import List, Optional, Deque, Dict
from functools import partial
import heapq

class Heap:
    def __init__(self, initial=None, key=lambda x:x):
        self.key = key
        self.index = 0
        if initial:
            self._data = [(key(item), i, item) for i, item in enumerate(initial)]
            self.index = len(self._data)
            heapq.heapify(self._data)
        else:
            self._data = []

    def push(self, item):
        heapq.heappush(self._data, (self.key(item), self.index, item))
        self.index += 1

    def pop(self):
        return heapq.heappop(self._data)[2]

    def is_empty(self):
        return len(self._data) == 0

    def __contains__(self, item):
        return item in [item for _, _, item in self._data]

class Searcher:
    def __init__(self):
        self.graph: List[Node] = None

    def set_graph(self, graph: List[Node]):
        self.graph = graph

    def dfs(self, src: Node, dst: Optional[Node]=None, visited: Optional[List[Node]]=None):
        if visited is None:
            visited = []
        found = self.dfs_util(src, visited, dst)
        if not found:
            unvisited = sorted([node for node in self.graph if node not in visited], key=lambda node: node.tag[1:])
            if unvisited:
                return self.dfs(unvisited[0], dst, visited)
        return (visited, found)

    def dfs_util(self, node: Node, visited: List[Node], dst: Optional[Node]):
        visited.append(node)
        if dst is not None and node == dst:
            return True

        adjacents = sorted(node.get_adjacent_nodes(), key=lambda node: node.tag[1:])
        for adj in adjacents:
            if adj not in visited and adj != node:
                if self.dfs_util(adj, visited, dst):
                    return True

        return False

    def bfs(self, src: Node, dst: Optional[Node]=None, visited: Optional[List[Node]]=None):
        if visited is None:
            visited = []
        found = False
        queue = deque([src])
        while queue:
            node = queue.popleft()
            if node == dst:
                found = True
                visited.append(node)
                break
            adjacents = sorted(node.get_adjacent_nodes(), key=lambda node: node.tag[1:])
            for adj in adjacents:
                if not (adj in visited or adj in queue) and adj != node:
                    queue.append(adj)
            visited.append(node)
        if not found:
            unvisited = sorted([node for node in self.graph if node not in visited], key=lambda node: node.tag[1:])
            return self.bfs(unvisited[0], dst, visited)
        return (visited, found)

    def iddfs(self, src: Node, dst: Node):
        max_depth = 0
        paths: Dict[int, List[Node]] = {}
        found = [False]
        while True:
            natural_failure = [True]
            path = deque([src])
            self.iddfs_util(max_depth, path, dst, natural_failure, found)
            # path = [node.tag[1:] for node in path]
            if max_depth != 0 and path == paths[max_depth-1]:
                break
            paths[max_depth] = path
            max_depth += 1
            if natural_failure[0] or found[0]:
                break
        return (paths, found[0])

    def iddfs_util(self, max_depth: int, path: Deque[Node], dst: Optional[Node], natural_failure: List[bool], found, prev_nodes: deque[Node]=None):
        if prev_nodes is None:
            prev_nodes = deque([])
        node = path[-1]
        if dst is not None:
            if node == dst and max_depth == 0:
                found[0] = True
                return

        if max_depth > 0:
            nodes = sorted(node.get_adjacent_nodes(), key=lambda node: node.tag[1:])
            prev_nodes.append(node)
            for adj in nodes:
                if adj != node and adj not in prev_nodes:
                    path.append(adj)
                    self.iddfs_util(max_depth-1, path, dst, natural_failure, found, prev_nodes)
            prev_nodes.pop()
        elif node.get_adjacent_nodes():
            natural_failure[0] = False

    def minimax(self, src: Node, is_maximizing, ab=False, depth=50, prev_src=None, alpha=None, beta=None):
        if alpha is None:
            alpha = float("-inf")
        if beta is None:
            beta = float("inf")
        if prev_src is None:
            prev_src = src
        adjacents: List[Node] = sorted(src.get_adjacent_nodes(), key=lambda node: node.tag[1:])
        try:
            adjacents.remove(prev_src)
            adjacents.remove(src)
        except ValueError:
            pass

        if depth == 0 or len(adjacents) == 0:
            if not is_maximizing:
                src.dark_mode = True
                src.redraw()
            return src.value, [src]

        if is_maximizing:
            best_value = float("-inf")
            best_path = []
            visited = set()
            for adj in adjacents:
                visited.add(adj)
                value, path = self.minimax(adj, False, ab, depth-1, src, alpha, beta)
                if value > best_value:
                    best_value = value
                    best_path = [src] + path
                alpha = max(alpha, value)
                if ab and beta <= alpha:
                    break
            if ab:
                unvisited = set(adjacents) - visited
                for adj in unvisited:
                    edges = src.get_edges_to(adj)
                    for edge in edges:
                        edge.dashed = True
                        edge.draw()
                x, y = src.center
                txt = beta if beta != float("inf") else "∞"
                src.additional_items.append(
                    partial(src.canvas.create_text, x, y-47, text=f"β: {txt}", font=("Arial", 10), tags=src.tag, fill="blue"))
                txt = alpha if alpha != float("-inf") else "-∞"
                src.additional_items.append(
                    partial(src.canvas.create_text, x, y-60, text=f"α: {txt}", font=("Arial", 10), tags=src.tag, fill="red"))
            src.set_value(best_value)
            return best_value, best_path
        else:
            src.dark_mode = True
            best_value = float("inf")
            best_path = []
            visited = set()
            for adj in adjacents:
                visited.add(adj)
                value, path = self.minimax(adj, True, ab, depth-1, src, alpha, beta)
                if value < best_value:
                    best_value = value
                    best_path = [src] + path
                beta = min(beta, value)
                if ab and beta <= alpha:
                    break
            if ab:
                unvisited = set(adjacents) - visited
                for adj in unvisited:
                    edges = src.get_edges_to(adj)
                    for edge in edges:
                        edge.dashed = True
                        edge.draw()
                x, y = src.center
                txt = beta if beta != float("inf") else "∞"
                src.additional_items.append(
                    partial(src.canvas.create_text, x, y-47, text=f"β: {txt}", font=("Arial", 10), tags=src.tag, fill="blue"))
                txt = alpha if alpha != float("-inf") else "-∞"
                src.additional_items.append(
                    partial(src.canvas.create_text, x, y-60, text=f"α: {txt}", font=("Arial", 10), tags=src.tag, fill="red"))
            src.set_value(best_value)
            return best_value, best_path

    def a_star(self, src: Node, dst: Node):
        def d(node1: Node, node2: Node):
            return min(node1.get_edges_to(node2), key=lambda edge: edge.weight).weight

        f_score = {node: float("inf") for node in self.graph}
        f_score[src] = src.value

        open_set = Heap([src], key=lambda node: f_score[node])
        came_from = {}

        g_score = {node: float("inf") for node in self.graph}
        g_score[src] = 0

        while not open_set.is_empty():
            current: Node = open_set.pop()
            if current == dst:
                path = [src]
                while current in came_from:
                    path.insert(1, current)
                    current = came_from[current]
                return path

            adjacents: List[Node] = sorted(current.get_adjacent_nodes(), key=lambda node: node.tag[1:])
            for adj in adjacents:
                tentative_g_score = g_score[current] + d(current, adj)
                if tentative_g_score < g_score[adj]:
                    came_from[adj] = current
                    g_score[adj] = tentative_g_score
                    f_score[adj] = g_score[adj] + adj.value
                    if adj not in open_set:
                        open_set.push(adj)
        return None

