import tkinter as tk
from view import View
from search_algos import Searcher

if __name__ == "__main__":
    searcher = Searcher()
    root = tk.Tk()
    root.title("Graph Search")
    view = View(root)
    view.setup()
    view.set_searcher(searcher)
    searcher.set_graph(view.graph.nodes)

    root.mainloop()